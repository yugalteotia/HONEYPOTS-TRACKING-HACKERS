function openwin(page){
	setVariables();
    newwin=window.open(page,"x",specs);
	newwin.opener=self;
  }
 
function setVariables() {
var leftmarg;
var topmarg;
if (navigator.appName == "Netscape") {
	innerW="window.innerWidth";
	innerH="window.innerHeight";
	leftmarg = (innerW/2)-144;
	topmarg = (innerH/2)-70;
}
else {
	innerW=document.body.clientWidth;
	innerH=document.body.clientHeight;
	leftmarg = (innerW/2)-144;
	topmarg = (innerH/2)-70;	
   }
	if (navigator.appName == 'Microsoft Internet Explorer') 
	{
		specs = 'toolbar=no,width=287,height=80,directories=no,status=no,scrollbars=no,resize=no,menubar=no,location=no,copyhistory=no,left='+leftmarg +',top='+topmarg+'';
	} 
	else 
	{
		specs = 'toolbar=no,width=287,height=80,directories=no,status=no,scrollbars=no,resize=no,menubar=no,location=no,copyhistory=no,screenx='+leftmarg +',screeny='+topmarg+'';
	}
}
