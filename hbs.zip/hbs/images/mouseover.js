function m_in(sitemap) {
        var imageSource = "images/btn_interactive_a.gif";
        sitemap.src = imageSource;
        window.status = ' ';
}

function m_out(sitemap) {
        var imageSource = "images/btn_interactive.gif";
        sitemap.src = imageSource;
    window.status = ' ';
}