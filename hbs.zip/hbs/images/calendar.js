/*  Calendar.js 
    combined Date and Currency validation and formatting functions
    authors:  Tony Maxymillian, Michael Gilligan, Robert Gardener
    
    global variables
        calDay  =  today's date
        money   =  a regular expression for testing currency values  money.test(str) will return true for a valid currency amount (no symbol)
        lt      =  less than
        gt      =  greater than
        month   =  empty
        day     =  empty
        year    =  empty
    
    global arrays
        months  =  names of all the months
        week    =  days of the week
    
    prototypes
        Date.prototype.format = dateFormat
        Date.prototype.period = DatePeriod
        
    functions
        SetToday() 
        ChangeDate(newdate)
        PopCalendar(x)
        dateKey()
        DatePeriod()
        FourDigitYear(year)
        GetProcDate(x, daysToPay)
        FormatDate(d)
        ValidDate(dVal, pastDate)
            note:  pastDate  0 = all dates
                             1 = future only (not today)
                             2 = past only (includes today)
        FormatCurrency(amt, delim)
        ValidCommerceDate(vDate, pastDate)
        FormatCommerceDate(vDate)
        FormatVoyagerDate(vDate, vFormat)
        CheckMoney(x)
        CheckForRecurring(payeeID, fSelect)
*/
var calDay = new Date(FourDigitYear(tdy.getYear()), tdy.getMonth(), tdy.getDate(),0,0,0);
var nextYearToday = new Date(FourDigitYear(tdy.getYear())+1, tdy.getMonth(), tdy.getDate(),0,0,0);
var money = /^(([1-9]\d*\.?\d{0,2})|(0?\.\d{0,2}))$/;

var lt = "<";
var gt = ">";
var e = "keyup";
var months = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
var week = new Array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
var month, day, year;

function ChangeDate(newdate){dateTarget.focus();dateTarget.value = newdate;dateTarget.blur();}
function PopCalendar(x) {
	dateTarget = eval(x);
	if(!dateTarget.disabled){
		month = 0;
		day = 0;
		year = 0;
		if(window.mycalendar) {
			if(!window.mycalendar.closed) {window.mycalendar.focus();window.mycalendar.location.href = "/popup/calendar.asp";return;}
		}
		mycalendar = window.open("/popup/calendar.asp","mycalendarwin","resizable=no,width=275,height=275");window.mycalendar.focus();
		if (mycalendar.opener == null) mycalendar.opener = self;
	}
}
function dateFormat() {
	var a = new Array();
	var s = "";
	if(dateFormat.arguments[0]) {a = dateFormat.arguments[0].split("/");}
	else { a = ["mm", "dd", "yyyy"]; }
	if(!a[2]) { return this; }
    
	for(var i = 0; i < a.length; i++) {
		if(/[m]+/i.test(a[i])) {
				if(a[i].length >= 2) {
					a[i] = String(this.getMonth() + 1);
					if(a[i].length == 1) { a[i] = "0" + a[i]; }
				}
				else { a[i] = String(this.getMonth() + 1); }
		}
		else if(/[d]+/i.test(a[i])) {
				if(a[i].length >= 2) {
					a[i] = String(this.getDate());
					if(a[i].length == 1) { a[i] = "0" + a[i]; }
				}
				else { a[i] = String(this.getDate()); }
		}
		else if(/[y]+/i.test(a[i])) {
            if((this.getFullYear()-2000) < 0) {a[i] = String(this.getFullYear()+100);}
            else{a[i] = String(this.getFullYear());}
			}
		else if(/[w]+/i.test(a[i])) {
			return this;
		}
		else { return this; }
	}
	
    return a[0] + "/" + a[1] + "/" + a[2];
}
Date.prototype.format = dateFormat

function DatePeriod() {
	var span = DatePeriod.arguments[0] * 86400000;
	var str = this.valueOf() + span;
	str = new Date(str);
	return str;
}
Date.prototype.period = DatePeriod

function FourDigitYear(year) {return (year >= 2000) ? year : year + 1900;}

function GetProcDate(x, daysToPay) {
    if(document.getElementById) {
        var strPaymentDate = eval("document.details.date" + x + ".value");
        if(strPaymentDate.length < 6) {return;}
        else {
            if(ValidDate(strPaymentDate, 1)) {
                var dtp;
                var dtPaymentDate = new Date(strPaymentDate);
                dtp = dtPaymentDate.period(daysToPay);
                    
                if(dtp.getDay() == 0) {dtp = dtp.period(1);} // skip Sunday
                if(dtp.getDay() == 6) {dtp = dtp.period(2);} // skip Saturday
                document.getElementById(x).innerHTML = dtp.format();
        		}
            // failed validation!
            else {
                var dtPaymentDate = new Date(strPaymentDate);
                var msg = "";
                
                if(ValidDate(strPaymentDate, 2)) {msg = "Please enter a future date for your Payment Date.";}
                if(dtPaymentDate > nextYearToday) {msg = "Please enter a Payment Date not more than 1 year in the future.";}
                if(msg != "") {
                    if(window.event.type == "blur" && e == "keyup") {}
                    else {
                        alert(msg);
                        eval("document.details.date" + x + ".value = ''");
                        eval("document.details.date" + x + ".focus()");
                    }
                    msg = "";
                    e = window.event.type;
                    return;
                }
                document.getElementById(x).innerHTML = "";
            }
        }
    }
}

var dateKey = /^(\d{1,2})(\D)(\d{1,2})(\D)((20)?\d{2})$/;

function FormatDate(d) {
	if(!dateKey.test(d)) { return ""; }
	d = d.replace(dateKey, "$1/$3/$5");
	var fList = new Array();
	var str;
	fList = d.split("/");
	if(fList[0].length == 1) { fList[0] = "0" + fList[0]; }
	if(fList[1].length == 1) { fList[1] = "0" + fList[1]; }
    if(fList[2].length == 2) { fList[2] = "20" + fList[2]; }
	str = fList[0] + "/" + fList[1] + "/" + fList[2];
	return str;
}
/*  pastDate  0 = all dates
              1 = future only (not today)
              2 = past only (includes today)
*/
function ValidDate(dVal, pastDate) {
    if(!dateKey.test(dVal)) { return false; }
	dVal = FormatDate(dVal);
	var enteredDate = new Date(dVal);
	var dList = new Array();
	dList = dVal.split("/");
    if(pastDate == 1) {if(enteredDate < calDay || enteredDate > nextYearToday) { return false; }}
	if(pastDate == 2) {if(enteredDate > calDay) { return false; }}    
 	var pattern = /[\s]/;
	if (dVal.match(pattern) != null) {return false;}
   
	return IsDate(dList[0],dList[1],dList[2]);
	function IsDate (month, day, year) {
		var daysInMonth = new Array(0,31,privDaysInFebruary(year),31,30,31,30,31,31,30,31,30,31);
		if ((year.length == 4 && Number(year) > 0) && (Number(month) >= 1 && Number(month) <= 12) && (Number(day) <= daysInMonth[Number(month)] && Number(day) > 0)) { return true; }
		else { return false; }
		function privDaysInFebruary(year) {
			return (((year % 4 == 0) && ((!(year % 100 == 0)) || (year % 400 == 0))) ? 29 : 28 );
		}
	}
}
function FormatCurrency(amt, delim) {
	var a, s, c;
	amt = amt.replace(/([^.0-9_]*|\s*)(\d*)/g, "$2");
	if(!/\.{1}/.test(amt)) { amt = amt + "."; }
	a = new Array().concat(amt.split("."));
	s = "";
	for(var i = a[0].length - 1; i >= 0; i--) {	s += a[0].charAt(i); }
	s = s.replace(/(\d{3})/g, "$1,");
	a[0] = "";
	for(var i = s.length - 1; i >= 0; i--) { a[0] += s.charAt(i); }
	while(a[1].length < 2) { a[1] += "0"; }
	if(delim) {
		return a[0].replace(/^\,(.*)/, "$1") + "." + a[1].slice(0, 2);
	}
	else {
		return a[0].replace(/([^.0-9_]*|\s*)(\d*)/g, "$2") + "." + a[1].slice(0, 2);
	}
}
function ValidCommerceDate(vDate, pastDate){
	var strDate;
	var tmpDate;
	var aryDate = new Array();

	if (dateKey.test(vDate)){
		aryDate = vDate.split("/");
		var tmpDate = new Date(vDate);
		if (aryDate[2].length == 2){
			strDate = tmpDate.getMonth() + 1 + '/' + tmpDate.getDate() + '/' + (Number(tmpDate.getFullYear()) + 100);
		}
		else{
			strDate = tmpDate.getMonth() + 1 + '/' + tmpDate.getDate() + '/' + tmpDate.getFullYear();
		}
		finiDate = new Date(strDate);
		if(pastDate){
			return (finiDate > tdy);
		}
		else{
			return true;
		}
	}
	else{
		return false;
	}
}
function FormatCommerceDate(vDate) {
	var rDate;
	var rMonth, rDay, rYear;
	var aryDate = new Array();
	dDate = new Date(vDate);
	var aryDate = new Array();
	aryDate = vDate.split("/");

	if (!dateKey.test(dDate)){
		rMonth = dDate.getMonth() + 1
		rDay = dDate.getDate()
		aryDate = vDate.split("/");
		if (aryDate[2].length == 2){
			rYear = dDate.getFullYear() + 100
		}
		else{
			rYear = dDate.getFullYear()
		}
		if (rMonth < 10){rMonth = '0' + rMonth}
		if (rDay < 10){rDay = '0' + rDay}
		rDate = rMonth + '/' + rDay + '/' + rYear
		return rDate;
	}
}
function FormatVoyagerDate(vDate, vFormat) {
	var aDate = new Array();
	var rDate;
	aDate = vDate.split("/");
	rDate = aDate[1] + "/" + aDate[2].substr(0, 2) + "/" + aDate[0];
	rDate = new Date(rDate);
	return rDate.format(vFormat);
}
function CheckMoney(x) {
	if(eval(x + ".value.length") == 0) { return false; }
	if(!money.test(eval(x + ".value"))) {
		alert("Please enter a valid Amount.");
		eval(x + ".value = ''");
        eval(x + ".focus()");
	}
	//else { eval(x + ".value = FormatCurrency(" + x + ".value)"); }
	return true;
}